public class Goat {
    public static void main(String[] args){
        System.out.println("Hi! Any code can be running here!");
    }
}
